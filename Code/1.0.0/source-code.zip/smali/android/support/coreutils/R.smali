.class public final Landroid/support/coreutils/R;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/coreutils/R$styleable;,
        Landroid/support/coreutils/R$style;,
        Landroid/support/coreutils/R$string;,
        Landroid/support/coreutils/R$layout;,
        Landroid/support/coreutils/R$integer;,
        Landroid/support/coreutils/R$id;,
        Landroid/support/coreutils/R$drawable;,
        Landroid/support/coreutils/R$dimen;,
        Landroid/support/coreutils/R$color;,
        Landroid/support/coreutils/R$attr;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
