.class public final Landroid/support/constraint/R$attr;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/constraint/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static final barrierAllowsGoneWidgets:I = 0x7f04003b

.field public static final barrierDirection:I = 0x7f04003c

.field public static final chainUseRtl:I = 0x7f040067

.field public static final constraintSet:I = 0x7f04009b

.field public static final constraint_referenced_ids:I = 0x7f04009c

.field public static final content:I = 0x7f04009d

.field public static final emptyVisibility:I = 0x7f0400cf

.field public static final layout_constrainedHeight:I = 0x7f040136

.field public static final layout_constrainedWidth:I = 0x7f040137

.field public static final layout_constraintBaseline_creator:I = 0x7f040138

.field public static final layout_constraintBaseline_toBaselineOf:I = 0x7f040139

.field public static final layout_constraintBottom_creator:I = 0x7f04013a

.field public static final layout_constraintBottom_toBottomOf:I = 0x7f04013b

.field public static final layout_constraintBottom_toTopOf:I = 0x7f04013c

.field public static final layout_constraintCircle:I = 0x7f04013d

.field public static final layout_constraintCircleAngle:I = 0x7f04013e

.field public static final layout_constraintCircleRadius:I = 0x7f04013f

.field public static final layout_constraintDimensionRatio:I = 0x7f040140

.field public static final layout_constraintEnd_toEndOf:I = 0x7f040141

.field public static final layout_constraintEnd_toStartOf:I = 0x7f040142

.field public static final layout_constraintGuide_begin:I = 0x7f040143

.field public static final layout_constraintGuide_end:I = 0x7f040144

.field public static final layout_constraintGuide_percent:I = 0x7f040145

.field public static final layout_constraintHeight_default:I = 0x7f040146

.field public static final layout_constraintHeight_max:I = 0x7f040147

.field public static final layout_constraintHeight_min:I = 0x7f040148

.field public static final layout_constraintHeight_percent:I = 0x7f040149

.field public static final layout_constraintHorizontal_bias:I = 0x7f04014a

.field public static final layout_constraintHorizontal_chainStyle:I = 0x7f04014b

.field public static final layout_constraintHorizontal_weight:I = 0x7f04014c

.field public static final layout_constraintLeft_creator:I = 0x7f04014d

.field public static final layout_constraintLeft_toLeftOf:I = 0x7f04014e

.field public static final layout_constraintLeft_toRightOf:I = 0x7f04014f

.field public static final layout_constraintRight_creator:I = 0x7f040150

.field public static final layout_constraintRight_toLeftOf:I = 0x7f040151

.field public static final layout_constraintRight_toRightOf:I = 0x7f040152

.field public static final layout_constraintStart_toEndOf:I = 0x7f040153

.field public static final layout_constraintStart_toStartOf:I = 0x7f040154

.field public static final layout_constraintTop_creator:I = 0x7f040155

.field public static final layout_constraintTop_toBottomOf:I = 0x7f040156

.field public static final layout_constraintTop_toTopOf:I = 0x7f040157

.field public static final layout_constraintVertical_bias:I = 0x7f040158

.field public static final layout_constraintVertical_chainStyle:I = 0x7f040159

.field public static final layout_constraintVertical_weight:I = 0x7f04015a

.field public static final layout_constraintWidth_default:I = 0x7f04015b

.field public static final layout_constraintWidth_max:I = 0x7f04015c

.field public static final layout_constraintWidth_min:I = 0x7f04015d

.field public static final layout_constraintWidth_percent:I = 0x7f04015e

.field public static final layout_editor_absoluteX:I = 0x7f040160

.field public static final layout_editor_absoluteY:I = 0x7f040161

.field public static final layout_goneMarginBottom:I = 0x7f040162

.field public static final layout_goneMarginEnd:I = 0x7f040163

.field public static final layout_goneMarginLeft:I = 0x7f040164

.field public static final layout_goneMarginRight:I = 0x7f040165

.field public static final layout_goneMarginStart:I = 0x7f040166

.field public static final layout_goneMarginTop:I = 0x7f040167

.field public static final layout_optimizationLevel:I = 0x7f04016a


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
