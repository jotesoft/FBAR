.class public final Landroid/support/v14/preference/R$bool;
.super Ljava/lang/Object;
.source ""


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v14/preference/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "bool"
.end annotation


# static fields
.field public static final abc_action_bar_embed_tabs:I = 0x7f050000

.field public static final abc_allow_stacked_button_bar:I = 0x7f050001

.field public static final abc_config_actionMenuItemAllCaps:I = 0x7f050002

.field public static final config_materialPreferenceIconSpaceReserved:I = 0x7f050003


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
